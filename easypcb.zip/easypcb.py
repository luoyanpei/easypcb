from tkinter import *
from tkinter.ttk import Progressbar
import time
import json
import base64
from os import name
from PIL import Image, ImageTk
#import requests
import cv2
import numpy as np
import xlwt
import pandas as pd
import os

def pcb_mode(IMAGE_FILEPATH_Init,savepath_init):
    import requests
    execl_savepath=savepath_init+"电路器件识别.xls"
    font = cv2.FONT_HERSHEY_PLAIN
    #IMAGE_FILEPATH = "C:/Users/10794/Desktop/dachuang/yanzheng/3.png" # 目标图片的 本地文件路径，支持jpg/png/bmp格式
    #img = cv2.imread("C://Users/10794/Desktop/dachuang/yanzheng/3.png")# 目标图片的 本地文件路径，支持jpg/png/bmp格式
    PARAMS = {"threshold": 0.8}# threshold: 默认值为建议阈值，请在 我的模型-模型效果-完整评估结果-详细评估 查看建议阈值
    MODEL_API_URL = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/detection/pcbmodle"# 服务详情 中的 接口地址
    workbook = xlwt.Workbook(encoding= 'ascii')
    savepath=savepath_init
    worksheet = workbook.add_sheet("My new Sheet")
    name={}
    i_1=0
    dirt=["name","Resistance","Capacitance","Inductance","Amplifier","rheostat","semiconductor","FET"]
    pcb_file_list=os.listdir(IMAGE_FILEPATH_Init)

    '''
    # 调用 API 需要 ACCESS_TOKEN。若已有 ACCESS_TOKEN 则于下方填入该字符串
    # 否则，留空 ACCESS_TOKEN，于下方填入 该模型部署的 API_KEY 以及 SECRET_KEY，会自动申请并显示新 ACCESS_TOKEN
    '''


    ACCESS_TOKEN = ""
    API_KEY = "2zCd48N7I0PMx9bHFRB0T6Cy"
    SECRET_KEY = "Z3UZQDGvR8GPsATWgsIzGzkAFGGXfuIS"


    def pcbimg_to_base64(IMAGE_FILEPATH):    #将电路图转化为base64模式
        print("1. 读取目标图片 '{}'".format(IMAGE_FILEPATH))
        with open(IMAGE_FILEPATH, 'rb') as f:
            base64_data = base64.b64encode(f.read())
            base64_str = base64_data.decode('UTF8')
        print("将 BASE64 编码后图片的字符串填入 PARAMS 的 'image' 字段")
        PARAMS["image"] = base64_str
        return PARAMS

    i_mode=0
    #i=1
    name_pcb=1
    i_write=1
    i_path=1
    for i_1 in range(8):
        worksheet.write(0,i_1, dirt[i_1])
    for f in pcb_file_list:
        if '.png' in f :
            IMAGE_FILEPATH=IMAGE_FILEPATH_Init+str(i_path)+".png"
            img = cv2.imread(IMAGE_FILEPATH)
            PARAMS=pcbimg_to_base64(IMAGE_FILEPATH)
            i_path=i_path+1
            if not ACCESS_TOKEN:#获取新的ACCESS_TOKEN
                print("2. ACCESS_TOKEN 为空，调用鉴权接口获取TOKEN")
                auth_url = "https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials"\
                        "&client_id={}&client_secret={}".format(API_KEY, SECRET_KEY)
                auth_resp = requests.get(auth_url)
                auth_resp_json = auth_resp.json()
                ACCESS_TOKEN = auth_resp_json["access_token"]
                print("新 ACCESS_TOKEN: {}".format(ACCESS_TOKEN))
                window.update()
            else:
                print("2. 使用已有 ACCESS_TOKEN")
            print("3. 向模型接口 'MODEL_API_URL' 发送请求")
            request_url = "{}?access_token={}".format(MODEL_API_URL, ACCESS_TOKEN)
            response = requests.post(url=request_url, json=PARAMS)
            response_json = response.json()
            response_str = json.dumps(response_json, indent=4, ensure_ascii=False)
            shuju=json.loads(response_str)#这里要用到json进行读取
            shuju1=shuju["results"]
            print("长度为：%d"%len(response_str))
            height=[]
            left=[]
            top=[]
            width=[]
            label=[]
            name_dirt={}
            Resistance=0
            Capacitance=0
            Inductance=0
            Amplifier=0
            rheostat=0
            semiconductor=0
            FET=0
            for i in range(len(shuju1)):
                shuju1_location=shuju1[i]["location"]#将字典获取的数值读取，从而转化为各种数值
                height.append(shuju1_location["height"])
                left.append(shuju1_location["left"])
                top.append(shuju1_location["top"])
                width.append(shuju1_location["width"])
                shuju_name=shuju1[i]["name"]
                print(shuju1[i]["name"])
                print(shuju1_location)
                if (shuju1[i]["name"] == "电感"):
                    color=(255,0,0)
                    name="Inductance"
                    Inductance=Inductance+1
                elif(shuju1[i]["name"] == "电阻"):
                    color=(0,255,255)
                    name="Resistance"
                    Resistance=Resistance+1
                elif(shuju1[i]["name"] == "电容"):
                    color=(0,0,255)
                    name="Capacitance"
                    Capacitance=Capacitance+1
                elif(shuju1[i]["name"] == "放大器"):
                    color=(255,255,0)
                    name="Amplifier"
                    Amplifier=Amplifier+1
                elif(shuju1[i]["name"] == "滑变电阻"):
                    color=(255,255,125)
                    name="slide rheostat"
                    rheostat=rheostat+1
                elif(shuju1[i]["name"] == "二极管"):
                    color=(125,125,0)
                    name="semiconductor"
                    semiconductor=semiconductor+1
                elif(shuju1[i]["name"] == "MOS管"):
                    color=(123,123,125)
                    name="FET"
                    FET=FET+1
                else:
                    color=(125,125,125)
                    name="???"
                cv2.rectangle(img, (int(left[i]), int(top[i])), (int(left[i]+height[i]),int(top[i])+int(width[i])), color, 3)
                cv2.putText(img, name, (int(left[i]), int(top[i])-10), font, 1.2, (255, 0, 0), 2)
                window.update()
            #print("结果:\n{}".format(response_str))# encoding:utf-8
            name_dirt['name']=str(i_mode+1)+".png"
            name_dirt['Inductance']=str(Inductance)
            name_dirt['Resistance']=str(Resistance)
            name_dirt['Capacitance']=str(Capacitance)
            name_dirt['Amplifier']=str(Amplifier)
            name_dirt['rheostat']=str(rheostat)
            name_dirt['semiconductor']=str(semiconductor)
            name_dirt['FET']=str(FET)
            i_mode=i_mode+1
            print(name_dirt)
        for i1 in range(len(name_dirt)):
            worksheet.write(i_write,i1, name_dirt[dirt[i1]])
        i_write=i_write+1
        workbook.save(execl_savepath)
        #cv2.imshow("fff", img)
        savepath=savepath+str(name_pcb)+"easydl.png"
        cv2.imwrite(savepath, img)
        name_pcb=name_pcb+1
        savepath=savepath_init
        import requests 
        # client_id 为官网获取的AK， client_secret 为官网获取的SK
        host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=2zCd48N7I0PMx9bHFRB0T6Cy&client_secret=Z3UZQDGvR8GPsATWgsIzGzkAFGGXfuIS'
        response = requests.get(host)
            #if response:
            #    print(response.json())





window = Tk()
window.title("工程图纸识别系统")
window.geometry("1000x600")
#建立标签1
lbl = Label(window, text="工程图纸识别系统",font=("Arial Bold", 30))#建立静态文本
#建立一个文本框
txt = Entry(window, width=100)
txt2 = Entry(window, width=100)
#建立标签3
lb3 = Label(window,text="请输入你的文件夹路径：",font=("Arial Bold", 10))#建立静态文本
#自己的logo
lb4 = Label(window,text="Designed by luoyanpei",font=("Arial Bold", 8))#建立静态文本
lb5 = Label(window,text="请输入你要保存文件的路径：",font=("Arial Bold", 10))#建立静态文本
#创建一个进度条框
#bar = Progressbar(window, length=100)
txt.place(x=100,y=130)
lbl.place(x=300, y=0)
lb3.place(x=100,y=100)
lb4.place(x=395,y=560)
lb5.place(x=100,y=150)
txt2.place(x=100,y=180)
#bar.place(x=410,  y=250)
def clicked():
    global photo
    global photo_1
    lb2 = Label(window,text="等待中...",font=("Arial Bold", 10))#建立静态文本
    lb2.place(x=430, y=250)
    for i in range(100):
        bar = Progressbar(window, length=100)
        bar['value'] = i+1
        bar.place(x=410,  y=270)
        window.update()
        time.sleep(0.1)
    lb2.configure(text="文件上传成功，开始识别！")
    lb2.place(x=390, y=250)
    IMAGE_FILEPATH_Init = txt.get()#获取文本框中输入的字符
    savepath_init = txt2.get()
    pcb_mode(IMAGE_FILEPATH_Init,savepath_init)
    lb2.configure(text="识别成功！")
    lb2.place(x=430, y=250)
    img_path_init_1=IMAGE_FILEPATH_Init+"1.png"
    img_path=savepath_init+"1easydl.png"
    img = Image.open(img_path)
    img_init = Image.open(img_path_init_1)
    photo = ImageTk.PhotoImage(img.resize((367,219)))
    photo_1 = ImageTk.PhotoImage(img_init.resize((367,219)))
    Label(window, image=photo).place(x=50, y=330)
    Label(window, image=photo_1).place(x=480, y=330)
#定义按钮
btn = Button(window, text="开始识别", command=clicked)
btn.place(x=430, y=220)
window.mainloop()